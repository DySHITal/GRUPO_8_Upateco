// Ejercicio 1
// Escribe una función que tome dos números como parámetros y devuelva la suma de ambos.

function sumar(numero1, numero2) {
    return numero1 + numero2;
  }
  
  
  const resultado = sumar(5, 7);
  console.log(resultado); 


 